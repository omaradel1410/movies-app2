export interface GenresDto {
  genres: Genre[];
}

export interface Genre {
  name: string;
  id: string;
}
